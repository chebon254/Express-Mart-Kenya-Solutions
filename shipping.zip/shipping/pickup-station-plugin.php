<?php
/**
 * Plugin Name: Pickup Station for WooCommerce
 * Plugin URI: https://your-website.com
 * Description: Modern pickup station selector for WooCommerce with HPOS support
 * Version: 2.0.0
 * Author: Your Name
 * Text Domain: pickup-station-wc
 * Domain Path: /languages
 * Requires at least: 6.0
 * Tested up to: 6.8
 * Requires PHP: 8.0
 * WC requires at least: 9.0
 * WC tested up to: 9.8
 */

// Prevent direct access
if (!defined('ABSPATH')) {
    exit;
}

// Define constants
define('PICKUP_STATION_VERSION', '2.0.0');
define('PICKUP_STATION_PATH', plugin_dir_path(__FILE__));
define('PICKUP_STATION_URL', plugin_dir_url(__FILE__));

// Check if WooCommerce is active
add_action('plugins_loaded', 'pickup_station_check_woocommerce');

function pickup_station_check_woocommerce() {
    if (!class_exists('WooCommerce')) {
        add_action('admin_notices', function() {
            echo '<div class="notice notice-error"><p>';
            echo esc_html__('Pickup Station for WooCommerce requires WooCommerce to be installed and active.', 'pickup-station-wc');
            echo '</p></div>';
        });
        return;
    }
    
    // Initialize the plugin
    new Pickup_Station_Plugin();
}

// HPOS Compatibility Declaration
add_action('before_woocommerce_init', function() {
    if (class_exists('\Automattic\WooCommerce\Utilities\FeaturesUtil')) {
        \Automattic\WooCommerce\Utilities\FeaturesUtil::declare_compatibility('custom_order_tables', __FILE__, true);
    }
});

/**
 * Main Plugin Class
 */
class Pickup_Station_Plugin {
    
    public function __construct() {
        // Activation/Deactivation hooks
        register_activation_hook(__FILE__, array($this, 'activate'));
        register_deactivation_hook(__FILE__, array($this, 'deactivate'));
        
        // Initialize
        add_action('init', array($this, 'init'));
        add_action('wp_enqueue_scripts', array($this, 'enqueue_scripts'));
        add_action('admin_enqueue_scripts', array($this, 'admin_enqueue_scripts'));
        
        // Admin
        add_action('admin_menu', array($this, 'add_admin_menu'));
        
        // AJAX handlers
        add_action('wp_ajax_save_pickup_station', array($this, 'ajax_save_pickup_station'));
        add_action('wp_ajax_delete_pickup_station', array($this, 'ajax_delete_pickup_station'));
        add_action('wp_ajax_get_pickup_station_details', array($this, 'ajax_get_pickup_station_details'));
        add_action('wp_ajax_nopriv_get_pickup_station_details', array($this, 'ajax_get_pickup_station_details'));
    }
    
    public function activate() {
        $this->create_tables();
        flush_rewrite_rules();
    }
    
    public function deactivate() {
        flush_rewrite_rules();
    }
    
    public function create_tables() {
        global $wpdb;
        
        $table_name = $wpdb->prefix . 'pickup_stations';
        
        $charset_collate = $wpdb->get_charset_collate();
        
        $sql = "CREATE TABLE $table_name (
            id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
            name varchar(200) NOT NULL,
            address text NOT NULL,
            city varchar(100) NOT NULL,
            phone varchar(30) NOT NULL,
            shipping_price decimal(10,2) NOT NULL DEFAULT 0.00,
            status varchar(20) NOT NULL DEFAULT 'active',
            created_at datetime DEFAULT CURRENT_TIMESTAMP,
            updated_at datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            PRIMARY KEY (id),
            KEY status (status),
            KEY city (city)
        ) $charset_collate;";
        
        require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
        dbDelta($sql);
        
        // Add version option
        update_option('pickup_station_db_version', PICKUP_STATION_VERSION);
    }
    
    public function init() {
        // Load text domain
        load_plugin_textdomain('pickup-station-wc', false, dirname(plugin_basename(__FILE__)) . '/languages');
        
        // Checkout hooks - Modern WooCommerce approach
        add_action('woocommerce_after_checkout_billing_form', array($this, 'add_pickup_selection_field'));
        add_action('woocommerce_checkout_process', array($this, 'validate_pickup_selection'));
        add_action('woocommerce_checkout_create_order', array($this, 'save_pickup_selection_to_order'));
        
        // Display hooks - HPOS compatible
        add_action('woocommerce_admin_order_data_after_billing_address', array($this, 'display_pickup_in_admin'));
        add_action('woocommerce_email_order_meta', array($this, 'display_pickup_in_email'), 10, 3);
        add_action('woocommerce_order_details_after_order_table', array($this, 'display_pickup_in_frontend'));
        
        // Shipping method
        add_action('woocommerce_shipping_init', array($this, 'init_pickup_shipping_method'));
        add_filter('woocommerce_shipping_methods', array($this, 'add_pickup_shipping_method'));
        
        // Cart/Checkout updates
        add_action('wp_ajax_woocommerce_update_order_review', array($this, 'update_shipping_on_checkout'));
        add_action('wp_ajax_nopriv_woocommerce_update_order_review', array($this, 'update_shipping_on_checkout'));
    }
    
    public function enqueue_scripts() {
        if (is_checkout()) {
            wp_enqueue_script(
                'pickup-station-checkout',
                PICKUP_STATION_URL . 'assets/checkout.js',
                array('jquery', 'wc-checkout'),
                PICKUP_STATION_VERSION,
                true
            );
            
            wp_localize_script('pickup-station-checkout', 'pickup_station_ajax', array(
                'ajax_url' => admin_url('admin-ajax.php'),
                'nonce' => wp_create_nonce('pickup_station_nonce'),
                'i18n' => array(
                    'select_station' => esc_html__('Please select a pickup station', 'pickup-station-wc'),
                    'loading' => esc_html__('Loading...', 'pickup-station-wc')
                )
            ));
            
            wp_enqueue_style(
                'pickup-station-checkout',
                PICKUP_STATION_URL . 'assets/checkout.css',
                array(),
                PICKUP_STATION_VERSION
            );
        }
    }
    
    public function admin_enqueue_scripts($hook) {
        if ($hook === 'toplevel_page_pickup-stations') {
            wp_enqueue_script(
                'pickup-station-admin',
                PICKUP_STATION_URL . 'assets/admin.js',
                array('jquery'),
                PICKUP_STATION_VERSION,
                true
            );
            
            wp_localize_script('pickup-station-admin', 'pickup_admin_ajax', array(
                'ajax_url' => admin_url('admin-ajax.php'),
                'nonce' => wp_create_nonce('pickup_station_admin_nonce'),
                'i18n' => array(
                    'confirm_delete' => esc_html__('Are you sure you want to delete this pickup station?', 'pickup-station-wc'),
                    'success_added' => esc_html__('Pickup station added successfully!', 'pickup-station-wc'),
                    'success_deleted' => esc_html__('Pickup station deleted successfully!', 'pickup-station-wc'),
                    'error_occurred' => esc_html__('An error occurred. Please try again.', 'pickup-station-wc')
                )
            ));
            
            wp_enqueue_style(
                'pickup-station-admin',
                PICKUP_STATION_URL . 'assets/admin.css',
                array(),
                PICKUP_STATION_VERSION
            );
        }
    }
    
    public function add_admin_menu() {
        add_menu_page(
            esc_html__('Pickup Stations', 'pickup-station-wc'),
            esc_html__('Pickup Stations', 'pickup-station-wc'),
            'manage_woocommerce',
            'pickup-stations',
            array($this, 'admin_page'),
            'dashicons-location-alt',
            56
        );
    }
    
    public function admin_page() {
        global $wpdb;
        $table_name = $wpdb->prefix . 'pickup_stations';
        
        // Handle form submission
        if (isset($_POST['submit_station']) && wp_verify_nonce($_POST['pickup_nonce'], 'pickup_station_admin_nonce')) {
            $this->handle_station_form();
        }
        
        $stations = $wpdb->get_results("SELECT * FROM $table_name WHERE status = 'active' ORDER BY name ASC");
        ?>
        <div class="wrap">
            <h1><?php esc_html_e('Pickup Stations', 'pickup-station-wc'); ?></h1>
            
            <div class="pickup-station-admin">
                <div class="pickup-station-form">
                    <h2><?php esc_html_e('Add New Pickup Station', 'pickup-station-wc'); ?></h2>
                    <form method="post" action="">
                        <?php wp_nonce_field('pickup_station_admin_nonce', 'pickup_nonce'); ?>
                        
                        <table class="form-table" role="presentation">
                            <tbody>
                                <tr>
                                    <th scope="row"><label for="station_name"><?php esc_html_e('Station Name', 'pickup-station-wc'); ?></label></th>
                                    <td><input name="station_name" type="text" id="station_name" class="regular-text" required /></td>
                                </tr>
                                <tr>
                                    <th scope="row"><label for="station_address"><?php esc_html_e('Address', 'pickup-station-wc'); ?></label></th>
                                    <td><textarea name="station_address" id="station_address" rows="3" cols="50" class="large-text" required></textarea></td>
                                </tr>
                                <tr>
                                    <th scope="row"><label for="station_city"><?php esc_html_e('City', 'pickup-station-wc'); ?></label></th>
                                    <td><input name="station_city" type="text" id="station_city" class="regular-text" required /></td>
                                </tr>
                                <tr>
                                    <th scope="row"><label for="station_phone"><?php esc_html_e('Phone', 'pickup-station-wc'); ?></label></th>
                                    <td><input name="station_phone" type="tel" id="station_phone" class="regular-text" required /></td>
                                </tr>
                                <tr>
                                    <th scope="row"><label for="shipping_price"><?php esc_html_e('Shipping Price', 'pickup-station-wc'); ?></label></th>
                                    <td>
                                        <input name="shipping_price" type="number" id="shipping_price" step="0.01" min="0" class="regular-text" required />
                                        <p class="description"><?php echo sprintf(esc_html__('Price in %s', 'pickup-station-wc'), get_woocommerce_currency()); ?></p>
                                    </td>
                                </tr>
                            </tbody>
                        </table>
                        
                        <p class="submit">
                            <input type="submit" name="submit_station" class="button-primary" value="<?php esc_attr_e('Add Pickup Station', 'pickup-station-wc'); ?>" />
                        </p>
                    </form>
                </div>
                
                <div class="pickup-stations-list">
                    <h2><?php esc_html_e('Existing Pickup Stations', 'pickup-station-wc'); ?></h2>
                    <?php if (empty($stations)): ?>
                        <p><?php esc_html_e('No pickup stations found. Add your first station above.', 'pickup-station-wc'); ?></p>
                    <?php else: ?>
                        <table class="wp-list-table widefat fixed striped">
                            <thead>
                                <tr>
                                    <th><?php esc_html_e('Name', 'pickup-station-wc'); ?></th>
                                    <th><?php esc_html_e('Address', 'pickup-station-wc'); ?></th>
                                    <th><?php esc_html_e('City', 'pickup-station-wc'); ?></th>
                                    <th><?php esc_html_e('Phone', 'pickup-station-wc'); ?></th>
                                    <th><?php esc_html_e('Shipping Price', 'pickup-station-wc'); ?></th>
                                    <th><?php esc_html_e('Actions', 'pickup-station-wc'); ?></th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($stations as $station): ?>
                                <tr>
                                    <td><?php echo esc_html($station->name); ?></td>
                                    <td><?php echo esc_html($station->address); ?></td>
                                    <td><?php echo esc_html($station->city); ?></td>
                                    <td><?php echo esc_html($station->phone); ?></td>
                                    <td><?php echo wc_price($station->shipping_price); ?></td>
                                    <td>
                                        <button type="button" class="button delete-station" data-id="<?php echo esc_attr($station->id); ?>">
                                            <?php esc_html_e('Delete', 'pickup-station-wc'); ?>
                                        </button>
                                    </td>
                                </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    <?php endif; ?>
                </div>
            </div>
        </div>
        <?php
    }
    
    private function handle_station_form() {
        global $wpdb;
        
        $table_name = $wpdb->prefix . 'pickup_stations';
        
        $result = $wpdb->insert(
            $table_name,
            array(
                'name' => sanitize_text_field($_POST['station_name']),
                'address' => sanitize_textarea_field($_POST['station_address']),
                'city' => sanitize_text_field($_POST['station_city']),
                'phone' => sanitize_text_field($_POST['station_phone']),
                'shipping_price' => floatval($_POST['shipping_price'])
            ),
            array('%s', '%s', '%s', '%s', '%f')
        );
        
        if ($result) {
            add_action('admin_notices', function() {
                echo '<div class="notice notice-success is-dismissible"><p>';
                echo esc_html__('Pickup station added successfully!', 'pickup-station-wc');
                echo '</p></div>';
            });
        } else {
            add_action('admin_notices', function() {
                echo '<div class="notice notice-error is-dismissible"><p>';
                echo esc_html__('Error adding pickup station. Please try again.', 'pickup-station-wc');
                echo '</p></div>';
            });
        }
    }
    
    public function add_pickup_selection_field($checkout) {
        global $wpdb;
        $table_name = $wpdb->prefix . 'pickup_stations';
        $stations = $wpdb->get_results($wpdb->prepare("SELECT * FROM $table_name WHERE status = %s ORDER BY name ASC", 'active'));
        
        if (empty($stations)) {
            return;
        }
        
        echo '<div id="pickup-station-selection" class="pickup-station-field">';
        echo '<h3>' . esc_html__('Pickup Station', 'pickup-station-wc') . '</h3>';
        
        $options = array('' => esc_html__('Select a pickup station', 'pickup-station-wc'));
        foreach ($stations as $station) {
            $options[$station->id] = sprintf('%s - %s', $station->name, wc_price($station->shipping_price));
        }
        
        woocommerce_form_field('pickup_station', array(
            'type' => 'select',
            'class' => array('pickup-station-dropdown form-row-wide'),
            'label' => esc_html__('Choose Pickup Location', 'pickup-station-wc'),
            'required' => true,
            'options' => $options
        ), $checkout->get_value('pickup_station'));
        
        echo '<div id="pickup-station-details" class="pickup-station-details"></div>';
        echo '</div>';
    }
    
    public function validate_pickup_selection() {
        if (empty($_POST['pickup_station'])) {
            wc_add_notice(esc_html__('Please select a pickup station.', 'pickup-station-wc'), 'error');
        }
    }
    
    public function save_pickup_selection_to_order($order) {
        if (!empty($_POST['pickup_station'])) {
            global $wpdb;
            $table_name = $wpdb->prefix . 'pickup_stations';
            $station = $wpdb->get_row($wpdb->prepare("SELECT * FROM $table_name WHERE id = %d", intval($_POST['pickup_station'])));
            
            if ($station) {
                // Use WooCommerce CRUD methods for HPOS compatibility
                $order->update_meta_data('_pickup_station_id', $station->id);
                $order->update_meta_data('_pickup_station_name', $station->name);
                $order->update_meta_data('_pickup_station_address', $station->address);
                $order->update_meta_data('_pickup_station_city', $station->city);
                $order->update_meta_data('_pickup_station_phone', $station->phone);
                $order->update_meta_data('_pickup_station_price', $station->shipping_price);
                $order->save();
            }
        }
    }
    
    public function display_pickup_in_admin($order) {
        // HPOS compatible order meta retrieval
        $station_name = $order->get_meta('_pickup_station_name');
        if ($station_name) {
            echo '<div class="pickup-station-admin-details">';
            echo '<h3>' . esc_html__('Pickup Station Details', 'pickup-station-wc') . '</h3>';
            echo '<p><strong>' . esc_html__('Station:', 'pickup-station-wc') . '</strong> ' . esc_html($station_name) . '</p>';
            echo '<p><strong>' . esc_html__('Address:', 'pickup-station-wc') . '</strong> ' . esc_html($order->get_meta('_pickup_station_address')) . '</p>';
            echo '<p><strong>' . esc_html__('City:', 'pickup-station-wc') . '</strong> ' . esc_html($order->get_meta('_pickup_station_city')) . '</p>';
            echo '<p><strong>' . esc_html__('Phone:', 'pickup-station-wc') . '</strong> ' . esc_html($order->get_meta('_pickup_station_phone')) . '</p>';
            echo '</div>';
        }
    }
    
    public function display_pickup_in_email($order, $sent_to_admin, $plain_text) {
        $station_name = $order->get_meta('_pickup_station_name');
        if ($station_name) {
            if ($plain_text) {
                echo "\n" . esc_html__('PICKUP STATION', 'pickup-station-wc') . "\n";
                echo esc_html__('Station: ', 'pickup-station-wc') . $station_name . "\n";
                echo esc_html__('Address: ', 'pickup-station-wc') . $order->get_meta('_pickup_station_address') . "\n";
                echo esc_html__('City: ', 'pickup-station-wc') . $order->get_meta('_pickup_station_city') . "\n";
                echo esc_html__('Phone: ', 'pickup-station-wc') . $order->get_meta('_pickup_station_phone') . "\n";
            } else {
                echo '<h2>' . esc_html__('Pickup Station', 'pickup-station-wc') . '</h2>';
                echo '<p><strong>' . esc_html__('Station:', 'pickup-station-wc') . '</strong> ' . esc_html($station_name) . '</p>';
                echo '<p><strong>' . esc_html__('Address:', 'pickup-station-wc') . '</strong> ' . esc_html($order->get_meta('_pickup_station_address')) . '</p>';
                echo '<p><strong>' . esc_html__('City:', 'pickup-station-wc') . '</strong> ' . esc_html($order->get_meta('_pickup_station_city')) . '</p>';
                echo '<p><strong>' . esc_html__('Phone:', 'pickup-station-wc') . '</strong> ' . esc_html($order->get_meta('_pickup_station_phone')) . '</p>';
            }
        }
    }
    
    public function display_pickup_in_frontend($order) {
        $station_name = $order->get_meta('_pickup_station_name');
        if ($station_name) {
            echo '<h2>' . esc_html__('Pickup Station', 'pickup-station-wc') . '</h2>';
            echo '<table class="woocommerce-table shop_table pickup-station-details">';
            echo '<tr><th>' . esc_html__('Station:', 'pickup-station-wc') . '</th><td>' . esc_html($station_name) . '</td></tr>';
            echo '<tr><th>' . esc_html__('Address:', 'pickup-station-wc') . '</th><td>' . esc_html($order->get_meta('_pickup_station_address')) . '</td></tr>';
            echo '<tr><th>' . esc_html__('City:', 'pickup-station-wc') . '</th><td>' . esc_html($order->get_meta('_pickup_station_city')) . '</td></tr>';
            echo '<tr><th>' . esc_html__('Phone:', 'pickup-station-wc') . '</th><td>' . esc_html($order->get_meta('_pickup_station_phone')) . '</td></tr>';
            echo '</table>';
        }
    }
    
    public function ajax_save_pickup_station() {
        check_ajax_referer('pickup_station_admin_nonce', 'nonce');
        
        if (!current_user_can('manage_woocommerce')) {
            wp_send_json_error(esc_html__('Unauthorized', 'pickup-station-wc'));
        }
        
        global $wpdb;
        $table_name = $wpdb->prefix . 'pickup_stations';
        
        $result = $wpdb->insert(
            $table_name,
            array(
                'name' => sanitize_text_field($_POST['station_name']),
                'address' => sanitize_textarea_field($_POST['station_address']),
                'city' => sanitize_text_field($_POST['station_city']),
                'phone' => sanitize_text_field($_POST['station_phone']),
                'shipping_price' => floatval($_POST['shipping_price'])
            ),
            array('%s', '%s', '%s', '%s', '%f')
        );
        
        if ($result) {
            wp_send_json_success(esc_html__('Station added successfully', 'pickup-station-wc'));
        } else {
            wp_send_json_error(esc_html__('Failed to add station', 'pickup-station-wc'));
        }
    }
    
    public function ajax_delete_pickup_station() {
        check_ajax_referer('pickup_station_admin_nonce', 'nonce');
        
        if (!current_user_can('manage_woocommerce')) {
            wp_send_json_error(esc_html__('Unauthorized', 'pickup-station-wc'));
        }
        
        global $wpdb;
        $table_name = $wpdb->prefix . 'pickup_stations';
        
        $result = $wpdb->update(
            $table_name,
            array('status' => 'deleted'),
            array('id' => intval($_POST['station_id'])),
            array('%s'),
            array('%d')
        );
        
        if ($result !== false) {
            wp_send_json_success(esc_html__('Station deleted successfully', 'pickup-station-wc'));
        } else {
            wp_send_json_error(esc_html__('Failed to delete station', 'pickup-station-wc'));
        }
    }
    
    public function ajax_get_pickup_station_details() {
        check_ajax_referer('pickup_station_nonce', 'nonce');
        
        if (empty($_POST['station_id'])) {
            wp_send_json_error('No station ID provided');
        }
        
        global $wpdb;
        $table_name = $wpdb->prefix . 'pickup_stations';
        $station = $wpdb->get_row($wpdb->prepare("SELECT * FROM $table_name WHERE id = %d AND status = 'active'", intval($_POST['station_id'])));
        
        if ($station) {
            wp_send_json_success(array(
                'name' => $station->name,
                'address' => $station->address,
                'city' => $station->city,
                'phone' => $station->phone,
                'price' => wc_price($station->shipping_price)
            ));
        } else {
            wp_send_json_error('Station not found');
        }
    }
    
    public function update_shipping_on_checkout() {
        // This ensures shipping rates are recalculated when pickup station changes
        WC()->cart->calculate_shipping();
    }
    
    public function init_pickup_shipping_method() {
        // Shipping method class is defined outside
    }
    
    public function add_pickup_shipping_method($methods) {
        $methods['pickup_station'] = 'WC_Pickup_Station_Shipping_Method';
        return $methods;
    }
}

/**
 * Pickup Station Shipping Method Class
 * Must be defined outside the main plugin class for proper PHP structure
 */
class WC_Pickup_Station_Shipping_Method extends WC_Shipping_Method {
    
    public function __construct($instance_id = 0) {
        $this->id = 'pickup_station';
        $this->instance_id = absint($instance_id);
        $this->method_title = esc_html__('Pickup Station', 'pickup-station-wc');
        $this->method_description = esc_html__('Allow customers to select pickup stations with custom pricing', 'pickup-station-wc');
        $this->supports = array(
            'shipping-zones',
            'instance-settings',
            'instance-settings-modal'
        );
        
        $this->init();
    }
    
    public function init() {
        $this->init_form_fields();
        $this->init_settings();
        
        $this->title = $this->get_option('title', $this->method_title);
        $this->enabled = $this->get_option('enabled', 'yes');
        
        add_action('woocommerce_update_options_shipping_' . $this->id, array($this, 'process_admin_options'));
    }
    
    public function init_form_fields() {
        $this->form_fields = array(
            'enabled' => array(
                'title' => esc_html__('Enable/Disable', 'pickup-station-wc'),
                'type' => 'checkbox',
                'label' => esc_html__('Enable pickup station shipping', 'pickup-station-wc'),
                'default' => 'yes'
            ),
            'title' => array(
                'title' => esc_html__('Method Title', 'pickup-station-wc'),
                'type' => 'text',
                'description' => esc_html__('This controls the title shown during checkout', 'pickup-station-wc'),
                'default' => esc_html__('Pickup Station', 'pickup-station-wc'),
                'desc_tip' => true
            )
        );
    }
    
    public function calculate_shipping($package = array()) {
        // Check if pickup station is selected
        if (isset($_POST['pickup_station']) && !empty($_POST['pickup_station'])) {
            global $wpdb;
            $table_name = $wpdb->prefix . 'pickup_stations';
            $station = $wpdb->get_row($wpdb->prepare("SELECT * FROM $table_name WHERE id = %d AND status = 'active'", intval($_POST['pickup_station'])));
            
            if ($station) {
                $rate = array(
                    'id' => $this->get_rate_id(),
                    'label' => sprintf('%s - %s', $this->title, $station->name),
                    'cost' => $station->shipping_price,
                    'package' => $package,
                    'meta_data' => array(
                        'pickup_station_id' => $station->id,
                        'pickup_station_name' => $station->name
                    )
                );
                
                $this->add_rate($rate);
            }
        }
    }
    
    public function is_available($package = array()) {
        return $this->enabled === 'yes';
    }
}